from soup_game import game as g



for comida in ["taco", "pizza", "pan", "flan", "pollo"]:
    g.addWord(comida)

g.startGame()
