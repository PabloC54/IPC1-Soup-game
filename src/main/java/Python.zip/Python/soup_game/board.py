import re, random

_word_pattern = "[a-z]{3}"
# TODO: diagonal orientations
_orientations = ["ver", "hor", "ver_rev", "hor_rev"]

import string
with string:
  _alphabet = string.ascii_lowercase

class Board:
    def __init__(self, height, width) -> None:
        self.height: int = height
        self.width: int = width

        self.words: list(list()) = []

        # [ word_dict, word_dict, ... ]

        # word_dict
        # {
        #   word = str,
        #   begin = (i, j),
        #   lenght = int,
        #   orientation = str
        # }

        self.matrix: list(list(str)) = []

        # [ [[],[],...], [[],[],...], ... ]

        for i in range(self.height):
            self.matrix.append([])
            for _ in range(self.width):
                self.matrix[i].append("-")

    def _word(self, lex: str) -> dict:

        for word in self.words:
            if word["word"] == lex:
                return word

        return False

    def add_word(self, word: str, orientation: str) -> bool:

        word = word.lower()

        is_word = re.search(_word_pattern, word) and (not " " in word)

        if is_word:

            if not orientation:
                orientations_temp = _orientations.copy()
            else:
                orientations_temp = [orientation]

            while orientations_temp:
                orientation = orientations_temp[
                    random.randint(0, len(orientations_temp) - 1)
                ]
                place = self._place(word, orientation)
                if place:
                    break
                orientations_temp.remove(orientation)

            else:
                return "couldn't be added"

            self.words.append(
                {
                    "word": word,
                    "begin": place,
                    "lenght": len(word),
                    "orientation": orientation,
                }
            )
            self._write(word, orientation, place)
            return "added" + str(self.words[-1])

        return "non-valid word"

    def _place(self, word: str, orientation: str) -> list:

        lenght = len(word)
        positions = []

        if orientation == "ver" and lenght <= self.height:

            for i in range(self.height - lenght + 1):
                for j in range(self.width):
                    positions.append([i, j])

            while positions:
                position = positions[random.randint(0, len(positions) - 1)]
                i, j = position
                for char in word:
                    if self.matrix[i][j] != "-" and self.matrix[i][j] != char:
                        break
                    i += 1

                else:
                    return position

        elif orientation == "hor" and lenght <= self.width:

            for i in range(self.height):
                for j in range(self.width - lenght + 1):
                    positions.append([i, j])

            while positions:
                position = positions[random.randint(0, len(positions) - 1)]
                i, j = position
                for char in word:
                    if self.matrix[i][j] != "-" and self.matrix[i][j] != char:
                        break
                    j += 1

                else:
                    return position

        elif orientation == "ver_rev" and lenght <= self.height:

            for i in range(lenght - 1, self.height):
                for j in range(self.width):
                    positions.append([i, j])

            while positions:
                position = positions[random.randint(0, len(positions) - 1)]
                i, j = position
                for char in word:
                    if self.matrix[i][j] != "-" and self.matrix[i][j] != char:
                        break
                    i -= 1

                else:
                    return position

        elif orientation == "hor_rev" and lenght <= self.width:

            for i in range(self.height):
                for j in range(lenght - 1, self.width):
                    positions.append([i, j])

            while positions:
                position = positions[random.randint(0, len(positions) - 1)]
                i, j = position
                for char in word:
                    if self.matrix[i][j] != "-" and self.matrix[i][j] != char:
                        break
                    j -= 1

                else:
                    return position

        return False

    def _write(self, word: str, orientation: str, place: list):

        i, j = place

        if orientation == "ver":
            for char in word:
                self.matrix[i][j] = char
                i += 1

        elif orientation == "hor":
            for char in word:
                self.matrix[i][j] = char
                j += 1

        elif orientation == "ver_rev":
            for char in word:
                self.matrix[i][j] = char
                i -= 1

        elif orientation == "hor_rev":
            for char in word:
                self.matrix[i][j] = char
                j -= 1

    def print(self) -> None:
        matrix = self.matrix.copy()

        for i in range(self.height):
            for j in range(self.width):
                if matrix[i][j] == "-":
                    matrix[i][j] = _alphabet[random.randint(0, len(_alphabet) - 1)]

        print("=" * (5 * self.width))
        for row in matrix:
            print(row)
        print("=" * (5 * self.width) + "\n")
