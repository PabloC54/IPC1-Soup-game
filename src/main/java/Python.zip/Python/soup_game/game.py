from board import Board

height, width = 0, 0

while height < 5 : height = int(input("Enter board height (5+): "))
while width < 5: width = int(input("Enter board width (5+): "))

board = Board(height, width)

def addWord(word: str, orientation: str = "") -> bool:
    return board.add_word(word, orientation)

def startGame() -> None:
    while board.words:
        board.print()
        
        x, y = input("Enter initial cell as 'x y' (1-indexed): ").split(" ")
        x, y = int(x) - 1, int(y) - 1

        xf, yf = -1, -1

        # while (x == xf) != (y == yf):
        xf, yf = input("Enter final cell as 'x y' (1-indexed): ").split(" ")
        xf, yf = int(xf) - 1, int(yf) - 1

        if y == yf:
            if xf > x: orientation = "hor"
            else: orientation = "hor_rev"

        else: # x = xf
            if yf > y: orientation = "ver"
            else: orientation = "ver_rev"

        word = ""

        if orientation == "ver":            
            for i in range(y, yf + 1):
                word += board.matrix[i][x]

        elif orientation == "hor":
            for j in range(x, xf + 1):
                word += board.matrix[y][j]

        elif orientation == "ver_rev":            
            for i in range(yf, y + 1):
                word = board.matrix[i][x] + word

        elif orientation == "hor_rev":
            for j in range(xf, x + 1):
                word = board.matrix[y][j] + word

        print(orientation)
        print("SELECTED: ", word)

        pal = board._word(word)

        if pal:
            print("found!")
            board._write("#"*pal["lenght"], pal["orientation"], pal["begin"])
            board.words.remove(pal)

        else:
            print("not a word")


    print("you found all words!!")
    
